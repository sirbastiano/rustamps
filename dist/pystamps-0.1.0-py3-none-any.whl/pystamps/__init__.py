"""pySTAMPS package."""

__all__ = ["__version__"]

try:
    from pystamps._version import version as __version__
except ImportError:  # pragma: no cover - source trees without generated version metadata
    __version__ = "0.0.0"
