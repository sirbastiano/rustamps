from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
from scipy import sparse

from pystamps.config import ToleranceConfig
from pystamps.io.dataset import discover_dataset
from pystamps.io.mat import read_mat

DEFAULT_GLOBS: tuple[str, ...] = (
    "PATCH_*/ps1.mat",
    "PATCH_*/pm1.mat",
    "PATCH_*/select1.mat",
    "PATCH_*/weed1.mat",
    "ps2.mat",
    "pm2.mat",
    "ph2.mat",
    "phuw2.mat",
    "scla2.mat",
    "mean_v.mat",
    "ifgstd2.mat",
    "uw_space_time.mat",
    "uw_grid.mat",
    "uw_interp.mat",
)


@dataclass(slots=True)
class FileComparison:
    relative_path: str
    ok: bool
    message: str


@dataclass(slots=True)
class VerificationReport:
    comparisons: list[FileComparison] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return all(c.ok for c in self.comparisons)


def _is_numeric(value: Any) -> bool:
    if isinstance(value, np.ndarray):
        return value.dtype.names is None and value.dtype.kind in {"b", "i", "u", "f", "c"}
    return isinstance(value, (bool, int, float, complex, np.bool_, np.number))


def _to_array(value: Any) -> np.ndarray:
    if isinstance(value, np.ndarray):
        return value
    return np.asarray(value)


def _collect_numeric(payload: Any, prefix: str = "") -> dict[str, np.ndarray]:
    out: dict[str, np.ndarray] = {}

    if sparse.issparse(payload):
        payload_csc = payload.tocsc()
        out[f"{prefix}.data" if prefix else "data"] = np.asarray(payload_csc.data)
        out[f"{prefix}.ir" if prefix else "ir"] = np.asarray(payload_csc.indices)
        out[f"{prefix}.jc" if prefix else "jc"] = np.asarray(payload_csc.indptr)
        return out

    if isinstance(payload, dict):
        for key, value in payload.items():
            next_prefix = f"{prefix}.{key}" if prefix else str(key)
            out.update(_collect_numeric(value, next_prefix))
        return out

    if isinstance(payload, list):
        for idx, value in enumerate(payload):
            next_prefix = f"{prefix}[{idx}]"
            out.update(_collect_numeric(value, next_prefix))
        return out

    if isinstance(payload, np.ndarray) and payload.dtype.names:
        # MATLAB v7.3 complex arrays are often represented as structured arrays
        # with fields like ('real', 'imag'). Compare fields independently.
        for field in payload.dtype.names:
            next_prefix = f"{prefix}.{field}" if prefix else field
            out.update(_collect_numeric(payload[field], next_prefix))
        return out

    if _is_numeric(payload):
        out[prefix] = _to_array(payload)

    return out


def _compare_mat(run_mat: Path, golden_mat: Path, tol: ToleranceConfig) -> tuple[bool, str]:
    run_payload = read_mat(run_mat)
    golden_payload = read_mat(golden_mat)
    rtol = float(tol.rtol)
    atol = float(tol.atol)

    run_numeric = _collect_numeric(run_payload)
    golden_numeric = _collect_numeric(golden_payload)

    golden_keys = set(golden_numeric)
    run_keys = set(run_numeric)

    missing = sorted(golden_keys - run_keys)
    if missing:
        return False, f"Missing numeric keys in run: {', '.join(missing[:8])}"

    for key in sorted(golden_keys):
        lhs = run_numeric[key]
        rhs = golden_numeric[key]

        if lhs.shape != rhs.shape:
            return False, f"Shape mismatch for key '{key}': {lhs.shape} != {rhs.shape}"

        wrap_key = False
        if tol.wrap_equivalence:
            wrap_key = key in tol.wrap_keys or any(key.endswith(f".{suffix}") for suffix in tol.wrap_keys)

        if wrap_key:
            period = float(tol.wrap_period)
            if np.iscomplexobj(lhs) or np.iscomplexobj(rhs):
                lhs_c = np.asarray(lhs, dtype=np.complex128)
                rhs_c = np.asarray(rhs, dtype=np.complex128)
                diff = np.angle(lhs_c * np.conj(rhs_c))
                both_nan = np.isnan(np.real(lhs_c)) & np.isnan(np.real(rhs_c))
            else:
                lhs_f = np.asarray(lhs, dtype=np.float64)
                rhs_f = np.asarray(rhs, dtype=np.float64)
                diff = lhs_f - rhs_f
                diff = (diff + period / 2.0) % period - period / 2.0
                both_nan = np.isnan(lhs_f) & np.isnan(rhs_f)
            close = np.isclose(np.asarray(diff, dtype=np.float64), 0.0, rtol=rtol, atol=atol, equal_nan=False)
            ok_wrap = np.all(close | both_nan)
            if not ok_wrap:
                max_abs = float(np.nanmax(np.abs(np.asarray(diff, dtype=np.float64)[~both_nan])))
                return False, f"Wrap mismatch for key '{key}', wrapped_max_abs={max_abs:.6g}"
            continue

        try:
            close = np.allclose(lhs, rhs, rtol=rtol, atol=atol, equal_nan=True)
        except TypeError:
            close = np.array_equal(lhs, rhs, equal_nan=True)
        if not close:
            lhs_f = np.asarray(lhs, dtype=np.float64)
            rhs_f = np.asarray(rhs, dtype=np.float64)
            max_abs = float(np.nanmax(np.abs(lhs_f - rhs_f)))
            return False, f"Value mismatch for key '{key}', max_abs={max_abs:.6g}"

    return True, f"Matched {len(golden_keys)} numeric keys"


def _iter_pattern_files(root: Path, pattern: str) -> list[Path]:
    if not pattern.startswith("PATCH_*/"):
        return sorted(root.glob(pattern))

    layout = discover_dataset(root)
    subpattern = pattern.split("/", 1)[1]
    files: list[Path] = []
    for patch in layout.patches:
        files.extend(sorted(patch.glob(subpattern)))
    return files


def verify_run_against_golden(
    run_root: str | Path,
    golden_root: str | Path,
    tolerance: ToleranceConfig,
    patterns: tuple[str, ...] = DEFAULT_GLOBS,
) -> VerificationReport:
    run_path = Path(run_root).resolve()
    golden_path = Path(golden_root).resolve()

    report = VerificationReport()

    golden_files: list[Path] = []
    for pattern in patterns:
        golden_files.extend(_iter_pattern_files(golden_path, pattern))

    if not golden_files:
        report.comparisons.append(
            FileComparison(relative_path="<dataset>", ok=False, message="No golden files found for selected patterns")
        )
        return report

    for golden_file in golden_files:
        rel = golden_file.relative_to(golden_path)
        run_file = run_path / rel
        if not run_file.exists():
            report.comparisons.append(FileComparison(str(rel), False, "Missing run artifact"))
            continue

        if golden_file.suffix.lower() == ".mat":
            ok, message = _compare_mat(run_file, golden_file, tolerance)
            report.comparisons.append(FileComparison(str(rel), ok, message))
        else:
            if run_file.stat().st_size == golden_file.stat().st_size:
                report.comparisons.append(FileComparison(str(rel), True, "File size matches"))
            else:
                report.comparisons.append(FileComparison(str(rel), False, "File size differs"))

    return report
